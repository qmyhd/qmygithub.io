// Creator: James O'Connell jgo2nja
// Last Updated: 06 February 2022

#include "StackNode.h"
#include "Stack.h"
#include "StackItr.h"

using namespace std;

StackNode::StackNode(){
  value = 0;
  next = NULL;
  previous = NULL;
}
